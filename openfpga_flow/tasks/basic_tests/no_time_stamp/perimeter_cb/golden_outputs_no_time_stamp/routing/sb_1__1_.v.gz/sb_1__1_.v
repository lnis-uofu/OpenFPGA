//-------------------------------------------
//	FPGA Synthesizable Verilog Netlist
//	Description: Verilog modules for Unique Switch Blocks[1][1]
//	Author: Xifan TANG
//	Organization: University of Utah
//-------------------------------------------
//----- Default net type -----
`default_nettype none

// ----- Verilog module for sb_1__1_ -----
module sb_1__1_(pReset,
                prog_clk,
                chany_top_in,
                top_left_grid_right_width_0_height_0_subtile_0__pin_O_0_,
                top_left_grid_right_width_0_height_0_subtile_0__pin_O_1_,
                top_left_grid_right_width_0_height_0_subtile_0__pin_O_2_,
                top_left_grid_right_width_0_height_0_subtile_0__pin_O_3_,
                chanx_right_in,
                right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_,
                right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_,
                right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_,
                right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_,
                chany_bottom_in,
                bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_0_,
                bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_1_,
                bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_2_,
                bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_3_,
                chanx_left_in,
                left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_,
                left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_,
                left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_,
                left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_,
                ccff_head,
                chany_top_out,
                chanx_right_out,
                chany_bottom_out,
                chanx_left_out,
                ccff_tail);
//----- GLOBAL PORTS -----
input [0:0] pReset;
//----- GLOBAL PORTS -----
input [0:0] prog_clk;
//----- INPUT PORTS -----
input [0:18] chany_top_in;
//----- INPUT PORTS -----
input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_0_;
//----- INPUT PORTS -----
input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_1_;
//----- INPUT PORTS -----
input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_2_;
//----- INPUT PORTS -----
input [0:0] top_left_grid_right_width_0_height_0_subtile_0__pin_O_3_;
//----- INPUT PORTS -----
input [0:18] chanx_right_in;
//----- INPUT PORTS -----
input [0:0] right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_;
//----- INPUT PORTS -----
input [0:0] right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_;
//----- INPUT PORTS -----
input [0:0] right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_;
//----- INPUT PORTS -----
input [0:0] right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_;
//----- INPUT PORTS -----
input [0:18] chany_bottom_in;
//----- INPUT PORTS -----
input [0:0] bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_0_;
//----- INPUT PORTS -----
input [0:0] bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_1_;
//----- INPUT PORTS -----
input [0:0] bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_2_;
//----- INPUT PORTS -----
input [0:0] bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_3_;
//----- INPUT PORTS -----
input [0:18] chanx_left_in;
//----- INPUT PORTS -----
input [0:0] left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_;
//----- INPUT PORTS -----
input [0:0] left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_;
//----- INPUT PORTS -----
input [0:0] left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_;
//----- INPUT PORTS -----
input [0:0] left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_;
//----- INPUT PORTS -----
input [0:0] ccff_head;
//----- OUTPUT PORTS -----
output [0:18] chany_top_out;
//----- OUTPUT PORTS -----
output [0:18] chanx_right_out;
//----- OUTPUT PORTS -----
output [0:18] chany_bottom_out;
//----- OUTPUT PORTS -----
output [0:18] chanx_left_out;
//----- OUTPUT PORTS -----
output [0:0] ccff_tail;

//----- BEGIN wire-connection ports -----
//----- END wire-connection ports -----


//----- BEGIN Registered ports -----
//----- END Registered ports -----


wire [0:1] mux_2level_tapbuf_size3_0_sram;
wire [0:1] mux_2level_tapbuf_size3_0_sram_inv;
wire [0:1] mux_2level_tapbuf_size3_1_sram;
wire [0:1] mux_2level_tapbuf_size3_1_sram_inv;
wire [0:1] mux_2level_tapbuf_size3_2_sram;
wire [0:1] mux_2level_tapbuf_size3_2_sram_inv;
wire [0:1] mux_2level_tapbuf_size3_3_sram;
wire [0:1] mux_2level_tapbuf_size3_3_sram_inv;
wire [0:1] mux_2level_tapbuf_size3_4_sram;
wire [0:1] mux_2level_tapbuf_size3_4_sram_inv;
wire [0:1] mux_2level_tapbuf_size3_5_sram;
wire [0:1] mux_2level_tapbuf_size3_5_sram_inv;
wire [0:0] mux_2level_tapbuf_size3_mem_0_ccff_tail;
wire [0:0] mux_2level_tapbuf_size3_mem_1_ccff_tail;
wire [0:0] mux_2level_tapbuf_size3_mem_2_ccff_tail;
wire [0:0] mux_2level_tapbuf_size3_mem_3_ccff_tail;
wire [0:0] mux_2level_tapbuf_size3_mem_4_ccff_tail;
wire [0:0] mux_2level_tapbuf_size3_mem_5_ccff_tail;
wire [0:5] mux_2level_tapbuf_size4_0_sram;
wire [0:5] mux_2level_tapbuf_size4_0_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_10_sram;
wire [0:5] mux_2level_tapbuf_size4_10_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_11_sram;
wire [0:5] mux_2level_tapbuf_size4_11_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_12_sram;
wire [0:5] mux_2level_tapbuf_size4_12_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_13_sram;
wire [0:5] mux_2level_tapbuf_size4_13_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_14_sram;
wire [0:5] mux_2level_tapbuf_size4_14_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_15_sram;
wire [0:5] mux_2level_tapbuf_size4_15_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_1_sram;
wire [0:5] mux_2level_tapbuf_size4_1_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_2_sram;
wire [0:5] mux_2level_tapbuf_size4_2_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_3_sram;
wire [0:5] mux_2level_tapbuf_size4_3_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_4_sram;
wire [0:5] mux_2level_tapbuf_size4_4_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_5_sram;
wire [0:5] mux_2level_tapbuf_size4_5_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_6_sram;
wire [0:5] mux_2level_tapbuf_size4_6_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_7_sram;
wire [0:5] mux_2level_tapbuf_size4_7_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_8_sram;
wire [0:5] mux_2level_tapbuf_size4_8_sram_inv;
wire [0:5] mux_2level_tapbuf_size4_9_sram;
wire [0:5] mux_2level_tapbuf_size4_9_sram_inv;
wire [0:0] mux_2level_tapbuf_size4_mem_0_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_10_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_11_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_12_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_13_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_14_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_1_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_2_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_3_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_4_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_5_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_6_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_7_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_8_ccff_tail;
wire [0:0] mux_2level_tapbuf_size4_mem_9_ccff_tail;
wire [0:5] mux_2level_tapbuf_size5_0_sram;
wire [0:5] mux_2level_tapbuf_size5_0_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_10_sram;
wire [0:5] mux_2level_tapbuf_size5_10_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_11_sram;
wire [0:5] mux_2level_tapbuf_size5_11_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_12_sram;
wire [0:5] mux_2level_tapbuf_size5_12_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_13_sram;
wire [0:5] mux_2level_tapbuf_size5_13_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_14_sram;
wire [0:5] mux_2level_tapbuf_size5_14_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_15_sram;
wire [0:5] mux_2level_tapbuf_size5_15_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_1_sram;
wire [0:5] mux_2level_tapbuf_size5_1_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_2_sram;
wire [0:5] mux_2level_tapbuf_size5_2_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_3_sram;
wire [0:5] mux_2level_tapbuf_size5_3_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_4_sram;
wire [0:5] mux_2level_tapbuf_size5_4_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_5_sram;
wire [0:5] mux_2level_tapbuf_size5_5_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_6_sram;
wire [0:5] mux_2level_tapbuf_size5_6_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_7_sram;
wire [0:5] mux_2level_tapbuf_size5_7_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_8_sram;
wire [0:5] mux_2level_tapbuf_size5_8_sram_inv;
wire [0:5] mux_2level_tapbuf_size5_9_sram;
wire [0:5] mux_2level_tapbuf_size5_9_sram_inv;
wire [0:0] mux_2level_tapbuf_size5_mem_0_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_10_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_11_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_12_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_13_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_14_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_15_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_1_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_2_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_3_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_4_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_5_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_6_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_7_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_8_ccff_tail;
wire [0:0] mux_2level_tapbuf_size5_mem_9_ccff_tail;

// ----- BEGIN Local short connections -----
// ----- Local connection due to Wire 0 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chany_bottom_out[1] = chany_top_in[0];
// ----- Local connection due to Wire 2 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chany_bottom_out[3] = chany_top_in[2];
// ----- Local connection due to Wire 4 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chany_bottom_out[5] = chany_top_in[4];
// ----- Local connection due to Wire 6 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chany_bottom_out[7] = chany_top_in[6];
// ----- Local connection due to Wire 8 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chany_bottom_out[9] = chany_top_in[8];
// ----- Local connection due to Wire 10 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chany_bottom_out[11] = chany_top_in[10];
// ----- Local connection due to Wire 12 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chany_bottom_out[13] = chany_top_in[12];
// ----- Local connection due to Wire 14 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chany_bottom_out[15] = chany_top_in[14];
// ----- Local connection due to Wire 23 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[1] = chanx_right_in[0];
// ----- Local connection due to Wire 25 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[3] = chanx_right_in[2];
// ----- Local connection due to Wire 27 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[5] = chanx_right_in[4];
// ----- Local connection due to Wire 29 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[7] = chanx_right_in[6];
// ----- Local connection due to Wire 31 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[9] = chanx_right_in[8];
// ----- Local connection due to Wire 33 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[11] = chanx_right_in[10];
// ----- Local connection due to Wire 35 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[13] = chanx_right_in[12];
// ----- Local connection due to Wire 37 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[15] = chanx_right_in[14];
// ----- Local connection due to Wire 39 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[16] = chanx_right_in[16];
// ----- Local connection due to Wire 40 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[17] = chanx_right_in[17];
// ----- Local connection due to Wire 41 -----
// ----- Net source id 0 -----
// ----- Net sink id 2 -----
	assign chanx_left_out[18] = chanx_right_in[18];
// ----- Local connection due to Wire 46 -----
// ----- Net source id 0 -----
// ----- Net sink id 0 -----
	assign chany_top_out[1] = chany_bottom_in[0];
// ----- Local connection due to Wire 48 -----
// ----- Net source id 0 -----
// ----- Net sink id 0 -----
	assign chany_top_out[3] = chany_bottom_in[2];
// ----- Local connection due to Wire 50 -----
// ----- Net source id 0 -----
// ----- Net sink id 0 -----
	assign chany_top_out[5] = chany_bottom_in[4];
// ----- Local connection due to Wire 52 -----
// ----- Net source id 0 -----
// ----- Net sink id 0 -----
	assign chany_top_out[7] = chany_bottom_in[6];
// ----- Local connection due to Wire 54 -----
// ----- Net source id 0 -----
// ----- Net sink id 0 -----
	assign chany_top_out[9] = chany_bottom_in[8];
// ----- Local connection due to Wire 56 -----
// ----- Net source id 0 -----
// ----- Net sink id 0 -----
	assign chany_top_out[11] = chany_bottom_in[10];
// ----- Local connection due to Wire 58 -----
// ----- Net source id 0 -----
// ----- Net sink id 0 -----
	assign chany_top_out[13] = chany_bottom_in[12];
// ----- Local connection due to Wire 60 -----
// ----- Net source id 0 -----
// ----- Net sink id 0 -----
	assign chany_top_out[15] = chany_bottom_in[14];
// ----- Local connection due to Wire 69 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[1] = chanx_left_in[0];
// ----- Local connection due to Wire 71 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[3] = chanx_left_in[2];
// ----- Local connection due to Wire 73 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[5] = chanx_left_in[4];
// ----- Local connection due to Wire 75 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[7] = chanx_left_in[6];
// ----- Local connection due to Wire 77 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[9] = chanx_left_in[8];
// ----- Local connection due to Wire 79 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[11] = chanx_left_in[10];
// ----- Local connection due to Wire 81 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[13] = chanx_left_in[12];
// ----- Local connection due to Wire 83 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[15] = chanx_left_in[14];
// ----- Local connection due to Wire 85 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[16] = chanx_left_in[16];
// ----- Local connection due to Wire 86 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[17] = chanx_left_in[17];
// ----- Local connection due to Wire 87 -----
// ----- Net source id 0 -----
// ----- Net sink id 1 -----
	assign chanx_right_out[18] = chanx_left_in[18];
// ----- END Local short connections -----
// ----- BEGIN Local output short connections -----
// ----- END Local output short connections -----

	mux_2level_tapbuf_size5 mux_top_track_0 (
		.in({top_left_grid_right_width_0_height_0_subtile_0__pin_O_0_, chanx_right_in[2:3], chanx_left_in[0:1]}),
		.sram(mux_2level_tapbuf_size5_0_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_0_sram_inv[0:5]),
		.out(chany_top_out[0]));

	mux_2level_tapbuf_size5 mux_top_track_4 (
		.in({top_left_grid_right_width_0_height_0_subtile_0__pin_O_1_, chanx_right_in[4:5], chanx_left_in[14:15]}),
		.sram(mux_2level_tapbuf_size5_1_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_1_sram_inv[0:5]),
		.out(chany_top_out[2]));

	mux_2level_tapbuf_size5 mux_top_track_8 (
		.in({top_left_grid_right_width_0_height_0_subtile_0__pin_O_2_, chanx_right_in[6:7], chanx_left_in[12:13]}),
		.sram(mux_2level_tapbuf_size5_2_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_2_sram_inv[0:5]),
		.out(chany_top_out[4]));

	mux_2level_tapbuf_size5 mux_top_track_12 (
		.in({top_left_grid_right_width_0_height_0_subtile_0__pin_O_3_, chanx_right_in[8:9], chanx_left_in[10:11]}),
		.sram(mux_2level_tapbuf_size5_3_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_3_sram_inv[0:5]),
		.out(chany_top_out[6]));

	mux_2level_tapbuf_size5 mux_right_track_0 (
		.in({chany_top_in[14:15], right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_, chany_bottom_in[12:13]}),
		.sram(mux_2level_tapbuf_size5_4_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_4_sram_inv[0:5]),
		.out(chanx_right_out[0]));

	mux_2level_tapbuf_size5 mux_right_track_4 (
		.in({chany_top_in[0:1], right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_, chany_bottom_in[10:11]}),
		.sram(mux_2level_tapbuf_size5_5_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_5_sram_inv[0:5]),
		.out(chanx_right_out[2]));

	mux_2level_tapbuf_size5 mux_right_track_8 (
		.in({chany_top_in[2:3], right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_, chany_bottom_in[8:9]}),
		.sram(mux_2level_tapbuf_size5_6_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_6_sram_inv[0:5]),
		.out(chanx_right_out[4]));

	mux_2level_tapbuf_size5 mux_right_track_12 (
		.in({chany_top_in[4:5], right_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_, chany_bottom_in[6:7]}),
		.sram(mux_2level_tapbuf_size5_7_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_7_sram_inv[0:5]),
		.out(chanx_right_out[6]));

	mux_2level_tapbuf_size5 mux_bottom_track_1 (
		.in({chanx_right_in[12:13], bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_0_, chanx_left_in[2:3]}),
		.sram(mux_2level_tapbuf_size5_8_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_8_sram_inv[0:5]),
		.out(chany_bottom_out[0]));

	mux_2level_tapbuf_size5 mux_bottom_track_5 (
		.in({chanx_right_in[10:11], bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_1_, chanx_left_in[4:5]}),
		.sram(mux_2level_tapbuf_size5_9_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_9_sram_inv[0:5]),
		.out(chany_bottom_out[2]));

	mux_2level_tapbuf_size5 mux_bottom_track_9 (
		.in({chanx_right_in[8:9], bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_2_, chanx_left_in[6:7]}),
		.sram(mux_2level_tapbuf_size5_10_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_10_sram_inv[0:5]),
		.out(chany_bottom_out[4]));

	mux_2level_tapbuf_size5 mux_bottom_track_13 (
		.in({chanx_right_in[6:7], bottom_left_grid_right_width_0_height_0_subtile_0__pin_O_3_, chanx_left_in[8:9]}),
		.sram(mux_2level_tapbuf_size5_11_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_11_sram_inv[0:5]),
		.out(chany_bottom_out[6]));

	mux_2level_tapbuf_size5 mux_left_track_1 (
		.in({chany_top_in[0:1], chany_bottom_in[14:15], left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_4_}),
		.sram(mux_2level_tapbuf_size5_12_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_12_sram_inv[0:5]),
		.out(chanx_left_out[0]));

	mux_2level_tapbuf_size5 mux_left_track_5 (
		.in({chany_top_in[14:15], chany_bottom_in[0:1], left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_5_}),
		.sram(mux_2level_tapbuf_size5_13_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_13_sram_inv[0:5]),
		.out(chanx_left_out[2]));

	mux_2level_tapbuf_size5 mux_left_track_9 (
		.in({chany_top_in[12:13], chany_bottom_in[2:3], left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_6_}),
		.sram(mux_2level_tapbuf_size5_14_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_14_sram_inv[0:5]),
		.out(chanx_left_out[4]));

	mux_2level_tapbuf_size5 mux_left_track_13 (
		.in({chany_top_in[10:11], chany_bottom_in[4:5], left_bottom_grid_top_width_0_height_0_subtile_0__pin_O_7_}),
		.sram(mux_2level_tapbuf_size5_15_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size5_15_sram_inv[0:5]),
		.out(chanx_left_out[6]));

	mux_2level_tapbuf_size5_mem mem_top_track_0 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(ccff_head),
		.ccff_tail(mux_2level_tapbuf_size5_mem_0_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_0_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_0_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_top_track_4 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_0_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_1_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_1_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_1_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_top_track_8 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_1_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_2_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_2_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_2_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_top_track_12 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_2_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_3_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_3_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_3_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_right_track_0 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size3_mem_2_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_4_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_4_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_4_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_right_track_4 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_4_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_5_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_5_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_5_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_right_track_8 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_5_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_6_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_6_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_6_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_right_track_12 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_6_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_7_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_7_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_7_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_bottom_track_1 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_7_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_8_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_8_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_8_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_bottom_track_5 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_8_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_9_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_9_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_9_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_bottom_track_9 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_9_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_10_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_10_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_10_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_bottom_track_13 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_10_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_11_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_11_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_11_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_left_track_1 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size3_mem_5_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_12_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_12_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_12_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_left_track_5 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_12_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_13_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_13_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_13_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_left_track_9 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_13_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_14_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_14_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_14_sram_inv[0:5]));

	mux_2level_tapbuf_size5_mem mem_left_track_13 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_14_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size5_mem_15_ccff_tail),
		.mem_out(mux_2level_tapbuf_size5_15_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size5_15_sram_inv[0:5]));

	mux_2level_tapbuf_size4 mux_top_track_16 (
		.in({chanx_right_in[10:11], chanx_left_in[8:9]}),
		.sram(mux_2level_tapbuf_size4_0_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_0_sram_inv[0:5]),
		.out(chany_top_out[8]));

	mux_2level_tapbuf_size4 mux_top_track_20 (
		.in({chanx_right_in[12:13], chanx_left_in[6:7]}),
		.sram(mux_2level_tapbuf_size4_1_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_1_sram_inv[0:5]),
		.out(chany_top_out[10]));

	mux_2level_tapbuf_size4 mux_top_track_24 (
		.in({chanx_right_in[14:15], chanx_left_in[4:5]}),
		.sram(mux_2level_tapbuf_size4_2_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_2_sram_inv[0:5]),
		.out(chany_top_out[12]));

	mux_2level_tapbuf_size4 mux_top_track_28 (
		.in({chanx_right_in[0:1], chanx_left_in[2:3]}),
		.sram(mux_2level_tapbuf_size4_3_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_3_sram_inv[0:5]),
		.out(chany_top_out[14]));

	mux_2level_tapbuf_size4 mux_right_track_16 (
		.in({chany_top_in[6:7], chany_bottom_in[4:5]}),
		.sram(mux_2level_tapbuf_size4_4_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_4_sram_inv[0:5]),
		.out(chanx_right_out[8]));

	mux_2level_tapbuf_size4 mux_right_track_20 (
		.in({chany_top_in[8:9], chany_bottom_in[2:3]}),
		.sram(mux_2level_tapbuf_size4_5_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_5_sram_inv[0:5]),
		.out(chanx_right_out[10]));

	mux_2level_tapbuf_size4 mux_right_track_24 (
		.in({chany_top_in[10:11], chany_bottom_in[0:1]}),
		.sram(mux_2level_tapbuf_size4_6_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_6_sram_inv[0:5]),
		.out(chanx_right_out[12]));

	mux_2level_tapbuf_size4 mux_right_track_28 (
		.in({chany_top_in[12:13], chany_bottom_in[14:15]}),
		.sram(mux_2level_tapbuf_size4_7_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_7_sram_inv[0:5]),
		.out(chanx_right_out[14]));

	mux_2level_tapbuf_size4 mux_bottom_track_17 (
		.in({chanx_right_in[4:5], chanx_left_in[10:11]}),
		.sram(mux_2level_tapbuf_size4_8_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_8_sram_inv[0:5]),
		.out(chany_bottom_out[8]));

	mux_2level_tapbuf_size4 mux_bottom_track_21 (
		.in({chanx_right_in[2:3], chanx_left_in[12:13]}),
		.sram(mux_2level_tapbuf_size4_9_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_9_sram_inv[0:5]),
		.out(chany_bottom_out[10]));

	mux_2level_tapbuf_size4 mux_bottom_track_25 (
		.in({chanx_right_in[0:1], chanx_left_in[14:15]}),
		.sram(mux_2level_tapbuf_size4_10_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_10_sram_inv[0:5]),
		.out(chany_bottom_out[12]));

	mux_2level_tapbuf_size4 mux_bottom_track_29 (
		.in({chanx_right_in[14:15], chanx_left_in[0:1]}),
		.sram(mux_2level_tapbuf_size4_11_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_11_sram_inv[0:5]),
		.out(chany_bottom_out[14]));

	mux_2level_tapbuf_size4 mux_left_track_17 (
		.in({chany_top_in[8:9], chany_bottom_in[6:7]}),
		.sram(mux_2level_tapbuf_size4_12_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_12_sram_inv[0:5]),
		.out(chanx_left_out[8]));

	mux_2level_tapbuf_size4 mux_left_track_21 (
		.in({chany_top_in[6:7], chany_bottom_in[8:9]}),
		.sram(mux_2level_tapbuf_size4_13_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_13_sram_inv[0:5]),
		.out(chanx_left_out[10]));

	mux_2level_tapbuf_size4 mux_left_track_25 (
		.in({chany_top_in[4:5], chany_bottom_in[10:11]}),
		.sram(mux_2level_tapbuf_size4_14_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_14_sram_inv[0:5]),
		.out(chanx_left_out[12]));

	mux_2level_tapbuf_size4 mux_left_track_29 (
		.in({chany_top_in[2:3], chany_bottom_in[12:13]}),
		.sram(mux_2level_tapbuf_size4_15_sram[0:5]),
		.sram_inv(mux_2level_tapbuf_size4_15_sram_inv[0:5]),
		.out(chanx_left_out[14]));

	mux_2level_tapbuf_size4_mem mem_top_track_16 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_3_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_0_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_0_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_0_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_top_track_20 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_0_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_1_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_1_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_1_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_top_track_24 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_1_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_2_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_2_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_2_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_top_track_28 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_2_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_3_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_3_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_3_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_right_track_16 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_7_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_4_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_4_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_4_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_right_track_20 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_4_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_5_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_5_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_5_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_right_track_24 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_5_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_6_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_6_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_6_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_right_track_28 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_6_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_7_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_7_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_7_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_bottom_track_17 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_11_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_8_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_8_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_8_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_bottom_track_21 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_8_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_9_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_9_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_9_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_bottom_track_25 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_9_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_10_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_10_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_10_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_bottom_track_29 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_10_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_11_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_11_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_11_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_left_track_17 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size5_mem_15_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_12_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_12_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_12_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_left_track_21 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_12_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_13_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_13_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_13_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_left_track_25 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_13_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size4_mem_14_ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_14_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_14_sram_inv[0:5]));

	mux_2level_tapbuf_size4_mem mem_left_track_29 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_14_ccff_tail),
		.ccff_tail(ccff_tail),
		.mem_out(mux_2level_tapbuf_size4_15_sram[0:5]),
		.mem_outb(mux_2level_tapbuf_size4_15_sram_inv[0:5]));

	mux_2level_tapbuf_size3 mux_top_track_32 (
		.in({chanx_right_in[16], chany_bottom_in[16], chanx_left_in[16]}),
		.sram(mux_2level_tapbuf_size3_0_sram[0:1]),
		.sram_inv(mux_2level_tapbuf_size3_0_sram_inv[0:1]),
		.out(chany_top_out[16]));

	mux_2level_tapbuf_size3 mux_top_track_34 (
		.in({chanx_right_in[17], chany_bottom_in[17], chanx_left_in[17]}),
		.sram(mux_2level_tapbuf_size3_1_sram[0:1]),
		.sram_inv(mux_2level_tapbuf_size3_1_sram_inv[0:1]),
		.out(chany_top_out[17]));

	mux_2level_tapbuf_size3 mux_top_track_36 (
		.in({chanx_right_in[18], chany_bottom_in[18], chanx_left_in[18]}),
		.sram(mux_2level_tapbuf_size3_2_sram[0:1]),
		.sram_inv(mux_2level_tapbuf_size3_2_sram_inv[0:1]),
		.out(chany_top_out[18]));

	mux_2level_tapbuf_size3 mux_bottom_track_33 (
		.in({chany_top_in[16], chanx_right_in[16], chanx_left_in[16]}),
		.sram(mux_2level_tapbuf_size3_3_sram[0:1]),
		.sram_inv(mux_2level_tapbuf_size3_3_sram_inv[0:1]),
		.out(chany_bottom_out[16]));

	mux_2level_tapbuf_size3 mux_bottom_track_35 (
		.in({chany_top_in[17], chanx_right_in[17], chanx_left_in[17]}),
		.sram(mux_2level_tapbuf_size3_4_sram[0:1]),
		.sram_inv(mux_2level_tapbuf_size3_4_sram_inv[0:1]),
		.out(chany_bottom_out[17]));

	mux_2level_tapbuf_size3 mux_bottom_track_37 (
		.in({chany_top_in[18], chanx_right_in[18], chanx_left_in[18]}),
		.sram(mux_2level_tapbuf_size3_5_sram[0:1]),
		.sram_inv(mux_2level_tapbuf_size3_5_sram_inv[0:1]),
		.out(chany_bottom_out[18]));

	mux_2level_tapbuf_size3_mem mem_top_track_32 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_3_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size3_mem_0_ccff_tail),
		.mem_out(mux_2level_tapbuf_size3_0_sram[0:1]),
		.mem_outb(mux_2level_tapbuf_size3_0_sram_inv[0:1]));

	mux_2level_tapbuf_size3_mem mem_top_track_34 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size3_mem_0_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size3_mem_1_ccff_tail),
		.mem_out(mux_2level_tapbuf_size3_1_sram[0:1]),
		.mem_outb(mux_2level_tapbuf_size3_1_sram_inv[0:1]));

	mux_2level_tapbuf_size3_mem mem_top_track_36 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size3_mem_1_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size3_mem_2_ccff_tail),
		.mem_out(mux_2level_tapbuf_size3_2_sram[0:1]),
		.mem_outb(mux_2level_tapbuf_size3_2_sram_inv[0:1]));

	mux_2level_tapbuf_size3_mem mem_bottom_track_33 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size4_mem_11_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size3_mem_3_ccff_tail),
		.mem_out(mux_2level_tapbuf_size3_3_sram[0:1]),
		.mem_outb(mux_2level_tapbuf_size3_3_sram_inv[0:1]));

	mux_2level_tapbuf_size3_mem mem_bottom_track_35 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size3_mem_3_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size3_mem_4_ccff_tail),
		.mem_out(mux_2level_tapbuf_size3_4_sram[0:1]),
		.mem_outb(mux_2level_tapbuf_size3_4_sram_inv[0:1]));

	mux_2level_tapbuf_size3_mem mem_bottom_track_37 (
		.pReset(pReset),
		.prog_clk(prog_clk),
		.ccff_head(mux_2level_tapbuf_size3_mem_4_ccff_tail),
		.ccff_tail(mux_2level_tapbuf_size3_mem_5_ccff_tail),
		.mem_out(mux_2level_tapbuf_size3_5_sram[0:1]),
		.mem_outb(mux_2level_tapbuf_size3_5_sram_inv[0:1]));

endmodule
// ----- END Verilog module for sb_1__1_ -----

//----- Default net type -----
`default_nettype wire



